Original data from https://github.com/liyaguang/DCRNN
